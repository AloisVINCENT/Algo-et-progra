#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <stdbool.h>

int rdm;
int ans;

int ask()
{
    printf("Entrez un entier entre 1 et 99\n");
    scanf("%i", &ans);
    if (ans < 0 || ans > 99)
    {
        ask();
    }
    return ans;
}

void game(int fraise, int framboise)
{
    fraise = ask();

    if (fraise > framboise)
    {
        printf("Plus petit\n");
        game(fraise, framboise);
    }
    else if (fraise < framboise)
    {
        printf("Plus grand\n");
        game(fraise, framboise);
    }
    else
    {
        printf("Gagné\n");
    }
}

int main()
{
    srand((unsigned int)time(NULL));
    rdm = random() % 99;
    game(ans, rdm);
}