#include <stdio.h>
#include <stdlib.h>

unsigned int fact();

int main()
{
    int n;
    printf("Entrez un entier : ");
    scanf("%i", &n);
    printf("\n%i factorielle = %u\n",n,fact(n));
}

unsigned int fact(unsigned int n)
{
    unsigned int a = 1;
    if (n == 0)
    {
        return 1;
    }
    else
    {
        for (unsigned int i = 1; i <= n; i++)
        {
            a = a * i;
        }
        return a;
    }
}