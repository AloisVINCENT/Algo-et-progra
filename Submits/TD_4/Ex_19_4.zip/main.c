#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <stdbool.h>
#include <math.h>

// prints a triangle of stars
void carre3(int n)
{
    for (int i = 0; i < n; i++)
    // loop for the number of rows
    {
        for (int j = 0; j < n; j++)
        // loop for the number of columns
        {
            if (j <= i)
            // if the column is less than or equal to the current row
            {
                printf("* ");
                // print a star
            }
            else
            {
                printf("  ");
                // print a space
            }
        }
        printf("\n");
    }
}

int main()
{
    int n;
    printf("Enter a number: ");
    scanf("%d", &n);
    carre3(n);
    printf("\n");
    return 0;
}
