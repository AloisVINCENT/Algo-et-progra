#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <stdbool.h>
#include <math.h>

// prints a number of stars without the diagonal line
void carre1(int n)
{
    for (int i = 0; i < n; i++)
    // loop for the number of rows
    {
        for (int j = 0; j < n; j++)
        // loop for the number of columns
        {
            if (j == n - i - 1)
            // if the column is equal to the number of rows minus the number of columns minus the current row
            {
                printf("  ");
                // print a space
            }
            else
            {
                printf("* ");
                // print a star
            }
        }
        printf("\n");
    }
}

int main()
{
    int n;
    printf("Enter a number: ");
    scanf("%d", &n);
    carre1(n);
    printf("\n");
    return 0;
}
