#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <stdbool.h>
#include <math.h>

// prints the opposite triangle of stars
void carre4(int n)
{
    for (int i = 0; i < n; i++)
    // loop for the number of rows
    {
        for (int j = 0; j < n; j++)
        // loop for the number of columns
        {
            if (j >= n - i - 1)
            // if the column is greater than or equal to the number of rows minus the number of columns minus the current row
            //(because the triangle is upside down)
            {
                printf("* ");
                // print a star
            }
            else
            {
                printf("  ");
                // print a space
            }
        }
        printf("\n");
    }
}

int main()
{
    int n;
    printf("Enter a number: ");
    scanf("%d", &n);
    carre4(n);
    printf("\n");
    return 0;
}
