#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <stdbool.h>
#include <math.h>

int carre(int n)
{
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < n; j++)
        {
            printf("* ");
        }
        printf("\n");
    }
  return 0;
}

int main()
{
    int n;
    printf("Enter a number: ");
    scanf("%d", &n);
    carre(n);
    printf("\n");
    return 0;
}
