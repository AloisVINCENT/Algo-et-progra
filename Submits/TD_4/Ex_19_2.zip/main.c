#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <stdbool.h>
#include <math.h>

// prints a number of stars without the other diagonal line
void carre2(int n)
{
    for (int i = 0; i < n; i++)
    // loop for the number of rows
    {
        for (int j = 0; j < n; j++)
        // loop for the number of columns
        {
            if (j == i)
            // if the column is equal to the current row
            {
                printf("  ");
                // print a space
            }
            else
            {
                printf("* ");
                // print a star
            }
        }
        printf("\n");
    }
}

int main()
{
    int n;
    printf("Enter a number: ");
    scanf("%d", &n);
    carre2(n);
    printf("\n");
    return 0;
}
