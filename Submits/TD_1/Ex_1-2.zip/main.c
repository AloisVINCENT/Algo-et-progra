// the good old Hello world...

int main () {
printf("Hello world!\n");
}