// the good old Hello world...
#include <stdio.h>
int main()
{
    for (int i = 0; i < 25; i++)
    {
        printf("Hello world!\n");
    }
}