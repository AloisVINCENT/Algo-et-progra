#include <stdio.h>
#include <stdlib.h>
int main()
{
  	char *nameLast;
    printf("Quel est ton nom ? \n");
    scanf("%ms", &nameLast);
    char *name1st;
    printf("Quel est ton prénom ? \n");
    scanf("%ms", &name1st);
    int age;
    printf("Quel âge as-tu ? \n");
    scanf("%i", &age);
    printf("Bonjour, %s %s, vous avez %i ans !", name1st, nameLast, age);
  	free(name1st);
  	free(nameLast);
}