#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a;
    unsigned int u;
    printf("Entrez un entier : \n");
    scanf("%i",&a);
    u = a;
    printf("%u\n",u);
}
